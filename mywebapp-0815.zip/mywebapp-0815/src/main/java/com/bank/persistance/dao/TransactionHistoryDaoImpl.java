package com.bank.persistance.dao;

import org.springframework.stereotype.Repository;

@Repository("transactionDao")
public class TransactionHistoryDaoImpl {

}
