/**
 * 
 */
package com.bank.persistance.model;

/**
 * @author cragh
 *
 */
public class TransactionHistory {

}
