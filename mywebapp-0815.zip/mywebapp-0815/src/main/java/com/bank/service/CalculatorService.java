package com.bank.service;

public class CalculatorService {

	public int add(Integer a, Integer b) {

		return a + b;
	}

	public int sub(Integer a, Integer b) {

		return a - b;
	}

}
